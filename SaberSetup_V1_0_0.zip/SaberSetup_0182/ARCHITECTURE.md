# Saber Setup architecture

```text
Saber Setup
│
├── Registration / lifecycle
│   └── __init__.py
│
├── Shared presentation layer
│   ├── ui.py
│   └── shared.py
│
├── SaberShader component
│   └── sabershader.py
│       ├── material / texture semantics
│       ├── face / hair / eyes
│       ├── outlines
│       └── render helpers
│
└── SaberRig component
    └── saberrig.py
        ├── semantic armature analysis
        ├── body / arm / leg / finger controls
        ├── IK / FK / animation spaces
        ├── secondary motion
        ├── QA
        └── bake / export
```

## Boundaries

`ui.py` may call public Blender operators from either component.

`shared.py` may inspect scene/selection state, but must not mutate shader or rig data.

`sabershader.py` and `saberrig.py` do not import one another.

This keeps failures attributable to one component and allows either subsystem to be
developed or tested independently.

## Next integration layer

The next safe addition is a small `workflow.py` orchestrator with a `Prepare Character`
operator. It should call public operators/stages rather than reaching into private
implementation helpers. The first version should stop on errors and report exactly
which stage failed.

## Persistent-data compatibility

Python/UI namespaces can be renamed freely; serialized Blender identifiers cannot.
The SaberShader component therefore has a small compatibility bridge for existing
`.blend` files. It copies old custom-property metadata to the current namespace at
build time and never requires SaberRig to understand shader internals.


## Workflow orchestration

`workflow.py` owns high-level setup orchestration. The SaberRig foundation remains a
low-level initialization step, while the unified `Build SaberRig` action creates the
actual animator-facing controls. Secondary Motion, bake and export remain explicit
user choices.


## Adaptive visual layer

`gothic_background.py` is presentation-only. It never calls SaberShader or SaberRig
implementation functions. The main panel marks its active View3D UI region via
`touch(context)`, and the draw handler generates the ornament from the region's live
width and height.

The handler token is stored in `bpy.app.driver_namespace` so an in-place addon reload
can remove the previous handler instead of leaking duplicate GPU callbacks.


## V0.1.7.1 presentation cleanup

The preview-icon theme module and its PNG assets were removed. All interactive UI
uses Blender-native icons again. `gothic_background.py` remains the only custom-drawn
presentation layer.


## V0.1.8 image background

`gothic_background.py` now draws the bundled transparent PNG rather than procedural
geometry. The image is loaded lazily after registration to remain safe under Blender's
restricted addon-install context. It scales from live UI-region dimensions and tiles
vertically while preserving aspect ratio.


## V0.1.8.1 presentation layer

Custom GPU/image background rendering has been removed. `ui.py` is the only
presentation layer and uses Blender-native `UILayout` controls. Saber Setup requires
no image assets.
