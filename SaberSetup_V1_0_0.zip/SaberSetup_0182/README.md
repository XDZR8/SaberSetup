# Saber Setup V0.1.8.2

Saber Setup packages SaberShader and SaberRig as one Blender 5.1+ addon.

## Architecture

- `sabershader.py` — material, texture, face, hair, eye and outline pipeline.
- `saberrig.py` — semantic rig analysis, controls, IK/FK, fingers, secondary motion, QA and bake/export.
- `shared.py` — read-only common context/status helpers.
- `ui.py` — one `Saber Setup` sidebar surface.
- `__init__.py` — package registration and rollback-safe orchestration.

## V0.1 integration rule

The two production systems remain independent internally. The unified panel provides
shortcuts and delegates the full detailed interfaces to the original component draw
methods. No shader algorithm calls SaberRig internals and no rig algorithm calls
SaberShader internals.

The intended manual order is:

1. Build SaberShader
2. Analyze Rig
3. Prepare SaberRig
4. Validate Rig

A future `Prepare Character` operator can orchestrate these stages after this packaging
layer has been tested in Blender.

## Installation

Zip the `SaberSetup` folder (the provided release ZIP already does this), install it as
a Blender addon, enable **Saber Setup**, then open:

`View3D > Sidebar (N) > Saber Setup`

## V0.1.1 compatibility guard

SaberShader now migrates serialized pre-release material/custom-property metadata
before rebuilding. This is necessary because Blender stores those identifiers in
`.blend` files. The migration is read-compatible only: new data continues to use
the `SaberShader` namespace.

If a generated/recovery material has no recoverable base texture, SaberShader now
fails closed and keeps the assigned material instead of replacing it with a white
shader.


## V0.1.2 — Full SaberRig workflow

The earlier Quick Workflow called `saberrig.prepare_foundation`. That action only
indexes source bones, creates the SaberRig collections and prepares the reusable
widget library. It intentionally creates no animator-control bones.

`Build SaberRig` now builds the animator-facing production setup:

1. Analyze the source rig.
2. Initialize the SaberRig foundation.
3. Build Master / Root / COG / Spine body controls.
4. Build Arm FK + IK.
5. Build Leg FK + IK and reverse-foot controls.
6. Build Finger Controls when semantic fingers are available.
7. Build Animation Spaces.
8. Attach and refresh control widgets.
9. Switch to Controls Only view and select Master.
10. Run Rig QA.

Secondary Motion remains opt-in.


## V0.1.3 — Standalone addon conflict guard

Saber Setup and the old standalone SaberRig/SaberShader addons must not be enabled
at the same time. They intentionally share Blender operator/property namespaces.

On registration, Saber Setup now checks enabled addon modules and stops before touching
Scene properties if a standalone `SaberRig*` or `SaberShader*` addon is active.

Recommended upgrade sequence:

1. Disable Saber Setup and any standalone SaberRig/SaberShader addons.
2. Restart Blender.
3. Enable only Saber Setup.


## V0.1.4 — Ghost preference guard fix

Blender may keep stale entries in `Preferences.addons` even after the corresponding
addon file has been deleted. V0.1.3 treated those stale records as active conflicts.

V0.1.4 blocks only standalone SaberRig/SaberShader modules that are still discoverable
on disk or already loaded in the current Blender session. Stale preference-only
records are ignored.


## V0.1.5 — Prominent SaberRig removal

Once the resolved armature contains a SaberRig foundation, the unified panel shows
`Remove SaberRig` above the Quick Workflow. The row uses Blender's native alert state
for a red/light-red destructive-action treatment. Blender's standard `UILayout`
buttons do not support an arbitrary custom RGB background, so this keeps the control
theme-compatible and clearly destructive.


## V0.1.6 — Gothic Metallic Native UI

The unified panel now uses Saber Setup's dark metallic visual language through bundled
preview icons while keeping Blender's native controls intact.

Palette accents:
- Dusty metallic rose: `#8C6878`
- Silver: `#A6A3AA`
- Antique gold: `#B39A63`
- SaberShader section: `#475C6E`
- SaberRig section: `#474F6E`
- SaberShader ready: `#6E6E47`
- Analyze Rig: `#475F6E`
- Validate Rig: `#4E6E47`

The UI intentionally does not display a palette-description subtitle.

Blender does not expose arbitrary per-panel or per-button RGB backgrounds through
`UILayout`. The exact palette therefore appears in custom preview accents/icons,
while buttons, hover, scaling and accessibility remain native.


## V0.1.6.1 — Upgrade-safe module loading

V0.1.6 introduced the new `ui_theme.py` module. When Blender installed V0.1.6 over
an already imported V0.1.5 session, `sabershader` existed in package globals but
`ui_theme` did not. The old all-or-nothing reload branch therefore attempted to
reload an undefined symbol.

Component loading is now per-module: existing modules are reloaded and newly added
modules are imported. This makes in-place Saber Setup upgrades safe when package
architecture gains a new module.


## V0.1.7 — Adaptive Gothic Background

Saber Setup now includes a procedural gothic ornament layer for the View3D Sidebar
while the Saber Setup panel is active.

The pattern:
- adapts its columns, cell size and repetition to the current sidebar dimensions;
- uses muted rose, wine, cool silver, antique gold and ink-blue accents;
- is generated procedurally, so it does not stretch a fixed image;
- is non-interactive and leaves Blender's native buttons responsible for input;
- exposes a `Gothic Background` toggle and strength slider in Status.

Blender's Python API provides draw handlers for space regions but no dedicated
per-Panel background-image property. The ornament therefore uses a restrained
UI-region `POST_PIXEL` draw layer. If a Blender build rejects UI-region handlers,
Saber Setup keeps all functional UI and reports `Background fallback active`.


## V0.1.7.1 — Visible Gothic Background + Native Icons

The custom preview-icon layer has been removed. The unified panel again uses Blender's
simple native icons.

The adaptive gothic ornament is now much more visible:
- default strength increased from 0.42 to 0.72;
- procedural line opacity increased substantially;
- antique-gold edge rails are stronger;
- line width increased slightly for high-DPI displays;
- the short idle timeout was removed;
- scenes still carrying exactly V0.1.7's untouched 0.42 default are migrated to 0.72.

The width/height adaptive pattern logic is unchanged.


## V0.1.7.2 — Restricted Data Registration Fix

Blender enables legacy addons inside a restricted registration context where
`bpy.data` is exposed as `_RestrictData`. V0.1.7.1 attempted to iterate
`bpy.data.scenes` during `register()`, which is not permitted there.

The 0.42 -> 0.72 background-strength migration is now deferred until the Saber Setup
panel is actually drawn, using `context.scene`. Registration no longer accesses
scene datablocks.


## V0.1.7.3 — Clean Loader / Restricted-Data Hardening

This release installs under the fresh Python module directory `SaberSetup_0173`.
The user-facing addon name remains `Saber Setup`.

This avoids reusing an older `SaberSetup` package cached in a running Blender process
after an in-place legacy-addon upgrade.

Registration hardening:
- no `bpy.data.scenes` access remains anywhere in the package;
- Gothic Background registration only defines its properties and draw handler;
- SaberShader scene metadata migration occurs only when Build SaberShader runs;
- an enabled older Saber Setup module is detected before registration.


## V0.1.8 — Adaptive Illustrated Background

The procedural gothic lattice has been replaced by the supplied PNG artwork.

The release contains a processed copy at:
`assets/panel_background.png`

Processing removes the white paper background and retains the character artwork as a
transparent watermark. The original aspect ratio is preserved. The artwork scales to
the current Sidebar width and repeats vertically for taller panels.

The background uses the same non-interactive UI-region draw layer as V0.1.7, while
all buttons and icons remain Blender-native.

Controls:
- `Illustrated Background` toggle
- background-strength slider (default `0.38`)


## V0.1.8.1 — Clean Native UI

The experimental illustrated background has been removed completely.

Removed:
- `gothic_background.py`
- `assets/panel_background.png`
- GPU background drawing
- background toggle and strength controls

The unified panel now uses Blender-native UI only. Quick Workflow has explicit
SaberShader and SaberRig headings, completed steps retain native depressed/check
states, and Remove SaberRig remains prominent.

Registration also clears stale visual draw-handler tokens from V0.1.7/V0.1.8.


## V0.1.8.2 — Source Style Alignment

Integration-layer comments and docstrings now follow the same clean-source convention
used for SaberShader and SaberRig: English, concise, current-purpose, and free of
development-history narration. No production behavior was changed.
