# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-
"""Shared target resolution and integration-status helpers."""

import bpy


def resolve_armature(context):
    """Resolve the most likely armature without changing selection or mode."""
    scene = getattr(context, "scene", None)
    if scene is not None and hasattr(scene, "saberrig_state"):
        target = getattr(scene.saberrig_state, "target", None)
        if target is not None and getattr(target, "type", None) == 'ARMATURE':
            return target

    active = getattr(context, "active_object", None)
    if active is not None:
        if getattr(active, "type", None) == 'ARMATURE':
            return active
        if getattr(active, "type", None) == 'MESH':
            try:
                arm = active.find_armature()
                if arm is not None:
                    return arm
            except Exception:
                pass
            for mod in getattr(active, "modifiers", ()):
                if getattr(mod, "type", None) == 'ARMATURE' and getattr(mod, "object", None):
                    return mod.object

    selected = [obj for obj in getattr(context, "selected_objects", ()) if obj.type == 'ARMATURE']
    if len(selected) == 1:
        return selected[0]

    view_layer = getattr(context, "view_layer", None)
    if view_layer is not None:
        visible = [
            obj for obj in view_layer.objects
            if obj.type == 'ARMATURE' and not obj.hide_get()
        ]
        if len(visible) == 1:
            return visible[0]
    return None


def integration_status(context):
    """Return non-invasive Shader/Rig status for the unified overview."""
    scene = context.scene
    armature = resolve_armature(context)

    shader_loaded = hasattr(scene, "sabershader_settings")
    shader_result = str(scene.get("XDZR8_BuildLastResult", "")) if shader_loaded else ""
    shader_running = bool(scene.get("XDZR8_BuildRunning", False)) if shader_loaded else False

    rig_loaded = hasattr(scene, "saberrig_state")
    rig_analyzed = bool(scene.saberrig_state.analyzed) if rig_loaded else False
    rig_prepared = bool(armature and armature.get("saberrig_prepared", False))
    rig_controls_ready = bool(
        armature
        and armature.get("saberrig_body_built", False)
        and armature.get("saberrig_arms_ik_built", False)
        and armature.get("saberrig_legs_ik_built", False)
    )

    return {
        "armature": armature,
        "shader_loaded": shader_loaded,
        "shader_result": shader_result,
        "shader_running": shader_running,
        "rig_loaded": rig_loaded,
        "rig_analyzed": rig_analyzed,
        "rig_prepared": rig_prepared,
        "rig_controls_ready": rig_controls_ready,
    }
