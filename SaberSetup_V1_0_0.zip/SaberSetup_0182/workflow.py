# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-
"""High-level workflows for Saber Setup."""

import bpy

from . import saberrig


def _set_stage(scene, stage, progress):
    scene["SaberSetup_RigBuildStage"] = str(stage)
    scene["SaberSetup_RigBuildProgress"] = int(progress)


def _select_master_control(context, arm_obj):
    """Finish on a visible animator control when possible."""
    try:
        saberrig._activate_armature(context, arm_obj, mode='POSE')
        for bone in arm_obj.data.bones:
            bone.select = False
        master_name = saberrig._body_control_names()["ctrl_master"]
        master = arm_obj.data.bones.get(master_name)
        if master:
            master.select = True
            arm_obj.data.bones.active = master
    except Exception:
        pass


class SABERSETUP_OT_build_rig(bpy.types.Operator):
    bl_idname = "sabersetup.build_rig"
    bl_label = "Build SaberRig"
    bl_description = (
        "Build the production SaberRig controls: body, arms, legs, fingers, "
        "animation spaces, custom shapes and final QA"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        state = scene.saberrig_state
        arm_obj = saberrig._resolve_armature(context, state)

        if not arm_obj:
            self.report({'ERROR'}, "SaberRig could not resolve a target armature")
            return {'CANCELLED'}
        if not saberrig._armature_is_editable(arm_obj):
            self.report({'ERROR'}, "Target armature is linked/read-only")
            return {'CANCELLED'}

        warnings = []
        try:
            _set_stage(scene, "Analyzing rig", 5)
            analysis = saberrig.analyze_armature(arm_obj)
            saberrig._fill_state(scene, state, arm_obj, analysis)

            _set_stage(scene, "Initializing foundation", 12)
            saberrig._prepare_foundation(arm_obj, analysis)

            _set_stage(scene, "Building body controls", 25)
            saberrig._build_body_controls(context, arm_obj, analysis)
            analysis = saberrig.analyze_armature(arm_obj)

            _set_stage(scene, "Building arm controls", 43)
            _arms, arm_errors = saberrig._build_arms_ik(context, arm_obj, analysis)
            if arm_errors:
                warnings.extend(f"Arms: {message}" for message in arm_errors)
            analysis = saberrig.analyze_armature(arm_obj)

            _set_stage(scene, "Building leg controls", 61)
            _legs, leg_errors = saberrig._build_legs_ik(context, arm_obj, analysis)
            if leg_errors:
                warnings.extend(f"Legs: {message}" for message in leg_errors)
            analysis = saberrig.analyze_armature(arm_obj)

            _set_stage(scene, "Building finger controls", 73)
            finger_segments = int(
                analysis.get("semantic_summary", {}).get("finger_segments_found", 0)
            )
            if finger_segments > 0:
                try:
                    _fingers, finger_errors = saberrig._build_finger_controls(
                        context, arm_obj, analysis
                    )
                    if finger_errors:
                        warnings.extend(
                            f"Fingers: {message}" for message in finger_errors
                        )
                except Exception as exc:
                    # The core body/IK rig remains useful without finger controls.
                    warnings.append(f"Fingers: {exc}")

            analysis = saberrig.analyze_armature(arm_obj)

            _set_stage(scene, "Building animation spaces", 84)
            try:
                saberrig._build_animation_spaces(context, arm_obj, analysis)
            except Exception as exc:
                warnings.append(f"Animation Spaces: {exc}")

            _set_stage(scene, "Refreshing control widgets", 91)
            widget_count = saberrig._setup_control_visuals(arm_obj)
            saberrig._set_rig_view(arm_obj, True)
            _select_master_control(context, arm_obj)

            _set_stage(scene, "Validating rig", 96)
            analysis = saberrig.analyze_armature(arm_obj)
            qa = saberrig._run_rig_qa(arm_obj, analysis)
            saberrig._fill_state(scene, state, arm_obj, analysis)

            arm_obj["sabersetup_rig_ready"] = True
            arm_obj["sabersetup_rig_build_version"] = "0.1.2"
            arm_obj["sabersetup_rig_build_warnings"] = int(len(warnings))
            scene["SaberSetup_RigBuildLastResult"] = "FINISHED"
            scene["SaberSetup_RigBuildError"] = ""
            scene["SaberSetup_RigBuildWarnings"] = "\n".join(warnings[:12])
            _set_stage(scene, "SaberRig ready", 100)

        except Exception as exc:
            scene["SaberSetup_RigBuildLastResult"] = "ERROR"
            scene["SaberSetup_RigBuildError"] = str(exc)
            self.report(
                {'ERROR'},
                f"SaberRig build stopped at "
                f"{scene.get('SaberSetup_RigBuildStage', 'unknown stage')}: {exc}"
            )
            return {'CANCELLED'}

        generated_count = len(saberrig._generated_bones(arm_obj))
        score = int(qa.get("score", arm_obj.get("saberrig_qa_score", 0)))
        message = (
            f"SaberRig ready · {generated_count} generated bones · "
            f"{widget_count} control widgets · QA {score}%"
        )
        if warnings:
            self.report({'WARNING'}, message + f" · {len(warnings)} warning(s)")
        else:
            self.report({'INFO'}, message)
        return {'FINISHED'}


CLASSES = (
    SABERSETUP_OT_build_rig,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
