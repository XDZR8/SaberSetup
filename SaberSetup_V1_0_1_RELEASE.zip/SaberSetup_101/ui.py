# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-
"""Unified Saber Setup user interface."""

import bpy

from . import sabershader
from . import saberrig
from . import shared
from . import workflow


CATEGORY = "Saber Setup"


class SABERSETUP_PT_main(bpy.types.Panel):
    bl_label = "Saber Setup"
    bl_idname = "SABERSETUP_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY

    def draw(self, context):
        layout = self.layout
        status = shared.integration_status(context)

        hero = layout.box()
        row = hero.row(align=True)
        row.scale_y = 1.15
        row.label(text="SABER SETUP", icon='TOOL_SETTINGS')
        right = row.row()
        right.alignment = 'RIGHT'
        right.label(text="V1.0.1")

        hero.label(text="Character shader + animation rig production toolkit")

        armature = status["armature"]
        target = hero.row(align=True)
        target.label(
            text=f"Target: {armature.name}" if armature else "Target: Auto / current character",
            icon='ARMATURE_DATA' if armature else 'EYEDROPPER',
        )

        # Show the destructive action only when a SaberRig setup exists.
        if status["rig_prepared"]:
            danger = layout.box()
            danger.alert = True
            remove_row = danger.row()
            remove_row.alert = True
            remove_row.scale_y = 1.35
            remove_row.operator(
                "saberrig.remove_setup",
                text="Remove SaberRig",
                icon='TRASH',
            )

        workflow = layout.box()
        workflow.label(text="Quick Workflow", icon='PLAY')

        shader_header = workflow.row()
        shader_header.label(text="SaberShader", icon='NODE_MATERIAL')

        row = workflow.row()
        row.scale_y = 1.35
        row.enabled = status["shader_loaded"]
        shader_ready = status["shader_result"] == "FINISHED" and not status["shader_running"]
        row.operator(
            sabershader.SABERSHADER_OT_add_shaders.bl_idname,
            text="SaberShader Ready" if shader_ready else "Build SaberShader",
            icon='CHECKMARK' if shader_ready else 'NODE_MATERIAL',
            depress=shader_ready,
        )

        workflow.separator()

        rig_header = workflow.row()
        rig_header.label(text="SaberRig", icon='ARMATURE_DATA')

        row = workflow.row(align=True)
        row.scale_y = 1.15
        row.enabled = status["rig_loaded"]
        row.operator(
            "saberrig.analyze_rig",
            text="Analyze Rig",
            icon='VIEWZOOM',
            depress=status["rig_analyzed"],
        )
        row.operator(
            "sabersetup.build_rig",
            text="Build SaberRig" if not status["rig_controls_ready"] else "Rebuild SaberRig ✓",
            icon='CHECKMARK' if status["rig_controls_ready"] else 'ARMATURE_DATA',
            depress=status["rig_controls_ready"],
        )

        row = workflow.row()
        row.enabled = status["rig_loaded"]
        row.operator("saberrig.run_rig_qa", text="Validate Rig", icon='CHECKMARK')

        info = workflow.box()
        info.label(text="Secondary Motion remains optional.", icon='INFO')

        state = layout.box()
        state.label(text="Status", icon='INFO')

        shader_row = state.row(align=True)
        if status["shader_running"]:
            shader_row.label(text="SaberShader: Building", icon='TIME')
        elif status["shader_result"] == "FINISHED":
            shader_row.label(text="SaberShader: Ready", icon='CHECKMARK')
        else:
            shader_row.label(text="SaberShader: Available", icon='MATERIAL')

        rig_row = state.row(align=True)
        if status["rig_controls_ready"]:
            rig_row.label(text="SaberRig: Controls ready", icon='CHECKMARK')
        elif status["rig_prepared"]:
            rig_row.label(text="SaberRig: Foundation initialized", icon='INFO')
        elif status["rig_analyzed"]:
            rig_row.label(text="SaberRig: Analyzed", icon='VIEWZOOM')
        else:
            rig_row.label(text="SaberRig: Available", icon='ARMATURE_DATA')

        stage = str(context.scene.get("SaberSetup_RigBuildStage", ""))
        result = str(context.scene.get("SaberSetup_RigBuildLastResult", ""))
        if stage and result in {"FINISHED", "ERROR"}:
            build_row = state.row()
            build_row.alert = (result == "ERROR")
            build_row.label(
                text=f"Rig build: {stage}",
                icon='ERROR' if result == "ERROR" else 'CHECKMARK',
            )



class SABERSETUP_PT_shader(bpy.types.Panel):
    bl_label = "SaberShader"
    bl_idname = "SABERSETUP_PT_shader"
    bl_parent_id = "SABERSETUP_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        # Delegate detailed controls to SaberShader's existing panel.
        sabershader.SABERSHADER_PT_main.draw(self, context)


class SABERSETUP_PT_rig(bpy.types.Panel):
    bl_label = "SaberRig"
    bl_idname = "SABERSETUP_PT_rig"
    bl_parent_id = "SABERSETUP_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = CATEGORY
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        # Delegate detailed controls to SaberRig's existing panel.
        saberrig.SR_PT_MainPanel.draw(self, context)


CLASSES = (
    SABERSETUP_PT_main,
    SABERSETUP_PT_shader,
    SABERSETUP_PT_rig,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
