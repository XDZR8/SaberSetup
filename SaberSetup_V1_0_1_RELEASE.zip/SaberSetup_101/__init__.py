# SPDX-License-Identifier: GPL-2.0-or-later
# -*- coding: utf-8 -*-

bl_info = {
    "name": "Saber Setup",
    "author": "Saber Project",
    "version": (1, 0, 1),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Saber Setup",
    "description": "Unified character setup toolkit combining SaberShader and SaberRig",
    "category": "3D View",
}

import importlib
import sys
import bpy
import addon_utils

def _load_component(name):
    """Load or reload one Saber Setup component safely."""
    existing = globals().get(name)
    if existing is None:
        return importlib.import_module(f".{name}", __package__)
    return importlib.reload(existing)


sabershader = _load_component("sabershader")
saberrig = _load_component("saberrig")
shared = _load_component("shared")
workflow = _load_component("workflow")
ui = _load_component("ui")


_COMPONENTS = (
    sabershader,
    saberrig,
    workflow,
    ui,
)


def _standalone_conflicts():
    """Return enabled Saber addons that conflict with this package."""
    try:
        enabled = set(bpy.context.preferences.addons.keys())
    except Exception:
        enabled = set()

    try:
        discovered = {
            getattr(mod, "__name__", "")
            for mod in addon_utils.modules(refresh=False)
        }
    except Exception:
        discovered = set()

    conflicts = []
    for module_name in sorted(enabled):
        lower = module_name.lower()
        if module_name == __package__:
            continue
        is_standalone_component = (
            lower.startswith("saberrig") or lower.startswith("sabershader")
        )
        is_other_sabersetup = (
            lower.startswith("sabersetup") and module_name != __package__
        )
        if not (is_standalone_component or is_other_sabersetup):
            continue

        is_discovered = module_name in discovered
        is_loaded = module_name in sys.modules
        if is_discovered or is_loaded:
            conflicts.append(module_name)

    return conflicts


def _cleanup_legacy_visual_handlers():
    """Clear stale Saber Setup visual draw-handler state."""
    for key in (
        "SABERSETUP_IMAGE_BG_HANDLE",
        "SABERSETUP_GOTHIC_UI_HANDLE",
    ):
        handle = bpy.app.driver_namespace.pop(key, None)
        if handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(handle, 'UI')
            except Exception:
                pass

    for key in (
        "SABERSETUP_IMAGE_BG_STATE",
        "SABERSETUP_IMAGE_BG_ERROR",
        "SABERSETUP_GOTHIC_UI_STATE",
        "SABERSETUP_GOTHIC_UI_ERROR",
    ):
        bpy.app.driver_namespace.pop(key, None)


def register():
    _cleanup_legacy_visual_handlers()

    conflicts = _standalone_conflicts()
    if conflicts:
        joined = ", ".join(conflicts)
        raise RuntimeError(
            "Saber Setup cannot be enabled while another Saber Setup or standalone "
            f"SaberRig/SaberShader addon is enabled: {joined}. Disable the older addon "
            "and then enable this Saber Setup version."
        )

    registered = []
    try:
        for component in _COMPONENTS:
            component.register()
            registered.append(component)
    except Exception:
        for component in reversed(registered):
            try:
                component.unregister()
            except Exception:
                pass
        raise


def unregister():
    errors = []
    for component in reversed(_COMPONENTS):
        try:
            component.unregister()
        except Exception as exc:
            errors.append((component.__name__, exc))
    if errors:
        details = "; ".join(f"{name}: {exc}" for name, exc in errors)
        raise RuntimeError(f"Saber Setup unregister completed with errors: {details}")
